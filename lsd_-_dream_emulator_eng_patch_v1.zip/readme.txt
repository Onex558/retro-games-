---------------------------------------------------------------------------------------------------
English Translation of LSD - Dream Emulator v.1 by Mr.Nobody & ArcaneAria
---------------------------------------------------------------------------------------------------

This is a english translation for the PS1 game LSD - Dream Emulator. 
This patch translates all text & image dialogs in the game.
Text dream translations are based off the LSD WIKI (https://dreamemulator.fandom.com/)
Apply the PPF patch to the bin images using a tool like PPF-o-Matic
or any other compatible software.
Enjoy!

Credits:
----------
Design & Hacking:			Mr.Nobody
Menu Translation: 			Arcanearia
Text-Dreams Translation: 		LSD : Dream Emulator Wiki

Bin info:
----------
File/ROM SHA-1: 46A4BFE2A4D8AD6FFB98C70345B2CC3982456557
File/ROM CRC32: 3469C9C8



PS. Don't forget to support more translations by subscribing 
and following me on the links below:

- Youtube:
https://goo.gl/sE58x7

- Blogger:
https://mrnobodystudios.blogspot.com/

- Twitter:
https://twitter.com/mrnobodystudios

- Translations:
http://www.romhacking.net/community/4650/